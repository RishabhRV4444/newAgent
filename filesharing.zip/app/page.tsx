"use client"

import { AppSidebar } from "../client/src/components/app-sidebar"

export default function SyntheticV0PageForDeployment() {
  return <AppSidebar />
}