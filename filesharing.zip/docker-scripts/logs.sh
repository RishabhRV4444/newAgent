#!/bin/bash
# View container logs

docker-compose logs -f arevei-cloud
