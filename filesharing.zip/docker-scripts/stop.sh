#!/bin/bash
# Stop the container

echo "Stopping AREVEI Cloud..."
docker-compose down

echo "✓ Container stopped!"
